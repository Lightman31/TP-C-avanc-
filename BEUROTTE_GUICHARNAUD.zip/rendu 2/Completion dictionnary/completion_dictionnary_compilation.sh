#!/bin/sh
gcc completion_dictionnary.c -o completion_dictionnary
