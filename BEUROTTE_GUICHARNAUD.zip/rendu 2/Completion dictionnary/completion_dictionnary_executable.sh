#!/bin/sh
if test -f ./completion_dictionnary; then

./completion_dictionnary

else echo please run completion_dictionnary_compilation.sh beforehand.

fi
