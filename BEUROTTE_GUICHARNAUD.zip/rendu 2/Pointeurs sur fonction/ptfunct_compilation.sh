#!/bin/sh
gcc ptfunct.c -o ptfunct
