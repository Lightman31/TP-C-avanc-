#!/bin/sh
if test -f ./ptfunct; then

./ptfunct

else echo please run ptfunct_compilation.sh beforehand.

fi
