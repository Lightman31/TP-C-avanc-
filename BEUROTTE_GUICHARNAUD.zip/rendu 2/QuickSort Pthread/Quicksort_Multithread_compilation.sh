#!/bin/sh
gcc Quicksort_Multithread.c -lpthread -o Quicksort_Multithread
