#!/bin/sh
if test -f ./Quicksort_Multithread; then

./Quicksort_Multithread

else echo please run Quicksort_Multithread_compilation.sh beforehand.

fi
