#!/bin/sh
gcc Quicksort.c -o Quicksort
