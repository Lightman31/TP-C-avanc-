#!/bin/sh
if test -f ./Quicksort; then

./Quicksort

else echo please run Quicksort_compilation.sh beforehand.

fi
